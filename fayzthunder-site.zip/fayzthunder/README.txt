# FayzThunder

Une première version interactive d'un réseau social gaming, en français.

## Lancer le site
1. Décompressez le dossier si nécessaire.
2. Ouvrez `index.html` dans un navigateur récent.

## Fonctionnalités de démonstration
- Fil de publications gaming
- Création de publications et association à un jeu
- Likes, commentaires et favoris
- Recherche dans les publications
- Filtres par jeu
- Interface responsive ordinateur/mobile
- Sauvegarde locale des publications dans le navigateur

## À savoir
Cette version est un prototype front-end : il n'y a pas encore de serveur, de comptes utilisateurs partagés, de messagerie réelle ni de modération côté serveur. Les publications sont stockées localement dans le navigateur utilisé. Pour un réseau social public, il faudra ajouter un backend, une authentification, une base de données, des règles de sécurité et des outils de modération.
